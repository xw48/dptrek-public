import { useState, useMemo, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import {
  Search, Lightbulb, BookOpen, FlaskConical, PenLine,
  ChevronLeft, ChevronRight, CheckCircle2, XCircle, Home
} from "lucide-react";

// PostHog Analytics
import {
  trackModuleStart,
  trackPhaseComplete,
  trackReflectionSubmit,
  trackTestComplete,
  trackModuleComplete,
  trackSurveyClick,
  trackInteractiveExampleStep
} from "../posthog";

// Module configs — add new modules here
import obstructionConfig from "../modules/obstruction/config";
import naggingConfig from '../modules/nagging/config.js';

const MODULE_CONFIGS = {
  1: obstructionConfig,
  2: naggingConfig,
  // 3: interfaceConfig,
};

const PHASES = ["experience", "reflection", "learning", "experiment", "test"];

const PHASE_META = {
  experience:  { label: "Experience",  Icon: Search        },
  reflection:  { label: "Reflection",  Icon: Lightbulb     },
  learning:    { label: "Learning",    Icon: BookOpen      },
  experiment:  { label: "Experiment",  Icon: FlaskConical  },
  test:        { label: "Test",        Icon: PenLine       },
};

function PhaseTab({ phase, isActive, isUnlocked, onClick }) {
  const { label, Icon } = PHASE_META[phase];
  return (
    <button
      onClick={() => isUnlocked && onClick(phase)}
      disabled={!isUnlocked}
      className={`flex flex-col items-center gap-1 px-4 py-3 rounded-xl text-xs font-bold transition-all
        ${isActive
          ? "bg-purple-600 text-white shadow-md scale-105"
          : isUnlocked
            ? "bg-white text-gray-600 hover:bg-purple-50 hover:text-purple-700 border border-gray-200"
            : "bg-gray-100 text-gray-300 cursor-not-allowed border border-gray-100"
        }`}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  );
}

function IframePhase({ phase, onNext, textSizeScale = { base: 'text-base', large: 'text-lg', xl: 'text-xl' } }) {
  const [showExitMessage, setShowExitMessage] = useState(false);
  const [showReportMessage, setShowReportMessage] = useState(false);
  const [showOverlay, setShowOverlay] = useState(phase.title === "Experiment"); // Show overlay for Experiment phase
  const [hasInteracted, setHasInteracted] = useState(false);

  // Listen for interaction inside iframe (for both Experience and Experiment)
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data.type === 'user_interacted') {
        setHasInteracted(true);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleExit = () => {
    setShowExitMessage(true);
    setTimeout(() => setShowExitMessage(false), 3000);
  };

  const handleReport = () => {
    setShowReportMessage(true);
    setTimeout(() => setShowReportMessage(false), 3000);
  };

  const handleStartExperiment = () => {
    setShowOverlay(false);
    // Don't auto-set hasInteracted - require actual simulation interaction
  };

  return (
    <div className="flex flex-col gap-4 sm:gap-6">
      <div className={`bg-blue-50 border border-blue-200 rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-blue-800 ${textSizeScale.base} font-medium`}>
        💡 {phase.instruction}
      </div>

      {/* Simulation Frame with Header */}
      <div className="rounded-2xl overflow-hidden border-2 border-gray-200 shadow-lg relative">
        {/* Simulation Header - Outside iframe */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-3 flex justify-between items-center border-b-4 border-amber-700">
          <button
            onClick={handleExit}
            className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-6 rounded-lg uppercase text-sm tracking-wide transition-all hover:scale-105 shadow-md"
          >
            Exit
          </button>
          <div className="bg-white text-amber-700 font-extrabold py-2 px-5 rounded-lg uppercase text-sm tracking-widest shadow-md">
            ⚠ Simulation Website
          </div>
          <button
            onClick={handleReport}
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-lg uppercase text-sm tracking-wide transition-all hover:scale-105 shadow-md"
          >
            Report
          </button>
        </div>

        {/* Iframe - Just the website content */}
        <div className={`w-full ${showOverlay ? 'filter blur-sm' : ''}`} style={{ height: "520px" }}>
          <iframe
            src={phase.iframeSrc}
            className="w-full h-full"
            title="Interactive simulation"
          />
        </div>

        {/* Overlay for Experiment Phase */}
        {showOverlay && (
          <div className="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-10 p-4 sm:p-6">
            <div className="bg-white rounded-2xl p-6 sm:p-8 max-w-2xl shadow-2xl border-4 border-purple-400 animate-fade-in">
              <h3 className={`${textSizeScale['2xl']} font-black text-gray-900 mb-4 flex items-center gap-3`}>
                <span className="text-3xl sm:text-4xl">🎯</span>
                Now Apply What You've Learned!
              </h3>
              
              <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-3 sm:p-4 mb-4 sm:mb-6">
                <p className={`${textSizeScale.base} text-amber-900 font-semibold mb-2`}>
                  <strong>Remember:</strong> The previous example requires many steps to reject cookies, while accepting cookies only requires one step.
                </p>
                <p className={`${textSizeScale.base} text-amber-800`}>
                  Even though it can be troublesome, you should still reject non-essential cookies.
                </p>
              </div>

              <p className={`${textSizeScale.large} text-gray-700 mb-4 sm:mb-6`}>
                Please apply the knowledge you've learned when exploring this example, and try your best to navigate away from the pattern and make decisions in favor of your benefits!
              </p>

              <button
                onClick={handleStartExperiment}
                className={`w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold ${textSizeScale.large} py-3 sm:py-4 px-6 sm:px-8 rounded-xl transition shadow-lg hover:shadow-2xl hover:scale-105 transform`}
              >
                Start Exercise →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Exit Message */}
      {showExitMessage && (
        <div className={`bg-green-50 border-2 border-green-400 rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-green-800 ${textSizeScale.base} font-medium animate-pulse`}>
          🚪 You exited the simulation! This is a good way to avoid deceptive practices.
        </div>
      )}

      {/* Report Message */}
      {showReportMessage && (
        <div className={`bg-blue-50 border-2 border-blue-400 rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-blue-800 ${textSizeScale.base} font-medium animate-pulse`}>
          📢 Thank you for reporting! This helps protect other users from deceptive patterns.
        </div>
      )}

      {/* Continue Button - Shows after interaction */}
      {hasInteracted ? (
        <div className="space-y-3">
          <div className={`bg-green-50 border-2 border-green-300 rounded-xl px-4 sm:px-5 py-2 sm:py-3 text-green-800 ${textSizeScale.base} font-medium text-center`}>
            ✅ Great! You tried it.
          </div>
          <div className="flex justify-end">
            <button onClick={onNext} className="btn-primary">
              Continue <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        <div className={`bg-purple-50 border-2 border-purple-300 rounded-xl px-4 sm:px-5 py-3 sm:py-4 text-purple-800 ${textSizeScale.base} font-medium text-center`}>
          👆 Please interact with the simulation above to continue
        </div>
      )}
    </div>
  );
}

function ReflectionPhase({ phase, onNext, textSizeScale = { base: 'text-base', large: 'text-lg', xl: 'text-xl', '2xl': 'text-2xl' } }) {
  const [answers, setAnswers] = useState({});
  const [otherText, setOtherText] = useState({});
  const [comments, setComments] = useState({});

  const allAnswered = phase.questions.every(q => {
    const hasAnswer = answers[q.id];
    // If "other" option is selected, check if text is provided
    if (hasAnswer && q.options.find(opt => opt.id === answers[q.id])?.needsText) {
      return otherText[q.id]?.trim();
    }
    return hasAnswer;
  });

  const handleAnswer = (qId, optId) => {
    setAnswers(prev => ({ ...prev, [qId]: optId }));
    // Clear other text if switching away from "other" option
    const option = phase.questions.find(q => q.id === qId)?.options.find(opt => opt.id === optId);
    if (!option?.needsText) {
      setOtherText(prev => {
        const newState = { ...prev };
        delete newState[qId];
        return newState;
      });
    }
  };

  const handleOtherText = (qId, text) => {
    setOtherText(prev => ({ ...prev, [qId]: text }));
  };

  const handleComment = (qId, text) => {
    setComments(prev => ({ ...prev, [qId]: text }));
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Helpful Header */}
      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white text-xl flex-shrink-0">
            💭
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">Share Your Thoughts</h3>
            <p className="text-sm text-gray-600">There are no wrong answers! We want to understand your experience and perspective.</p>
          </div>
        </div>
      </div>

      {/* Questions */}
      {phase.questions.map((q, i) => {
        const selectedOption = q.options.find(opt => opt.id === answers[q.id]);
        const needsOtherText = selectedOption?.needsText;

        return (
          <div key={q.id} className="bg-white border-2 border-gray-200 rounded-2xl p-5 sm:p-6 shadow-sm hover:shadow-md transition">
            <p className="text-base sm:text-lg font-bold text-gray-900 mb-4">
              {i + 1}. {q.question}
            </p>
            
            {/* Options */}
            <div className="space-y-2.5">
              {q.options.map(opt => {
                const isSelected = answers[q.id] === opt.id;

                return (
                  <div key={opt.id}>
                    <button
                      onClick={() => handleAnswer(q.id, opt.id)}
                      className={`w-full text-left px-4 py-3.5 rounded-xl text-sm sm:text-base font-medium transition-all flex items-center gap-3 ${
                        isSelected
                          ? 'border-2 border-purple-500 bg-purple-50 text-purple-900 shadow-sm'
                          : 'border-2 border-gray-200 bg-white text-gray-700 hover:border-purple-300 hover:bg-purple-50'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition ${
                        isSelected ? 'border-purple-500 bg-purple-500' : 'border-gray-400'
                      }`}>
                        {isSelected && (
                          <div className="w-2 h-2 rounded-full bg-white"></div>
                        )}
                      </div>
                      <span className="flex-1">{opt.text}</span>
                    </button>
                    
                    {/* "Other" text input */}
                    {isSelected && opt.needsText && (
                      <div className="mt-2 ml-8">
                        <textarea
                          value={otherText[q.id] || ''}
                          onChange={(e) => handleOtherText(q.id, e.target.value)}
                          placeholder="Please share your thoughts..."
                          className="w-full px-4 py-3 border-2 border-purple-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                          rows="3"
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Optional Comment Field */}
            {answers[q.id] && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  💬 Additional thoughts? (Optional)
                </label>
                <textarea
                  value={comments[q.id] || ''}
                  onChange={(e) => handleComment(q.id, e.target.value)}
                  placeholder="Feel free to share any additional thoughts or examples..."
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent resize-none"
                  rows="2"
                />
              </div>
            )}
          </div>
        );
      })}

      {/* Progress Indicator */}
      <div className="flex items-center gap-3 px-2">
        <div className="flex-1 bg-gray-200 rounded-full h-2">
          <div
            className="bg-purple-500 h-2 rounded-full transition-all duration-300"
            style={{
              width: `${(Object.keys(answers).length / phase.questions.length) * 100}%`
            }}
          />
        </div>
        <span className="text-sm font-semibold text-gray-600">
          {Object.keys(answers).length} / {phase.questions.length}
        </span>
      </div>

      {/* Continue Button */}
      {allAnswered && (
        <div className="flex justify-end pt-2">
          <button onClick={onNext} className="btn-primary">
            Continue <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}

// Interactive Example Component - Card Stacking with Better Space Usage
function InteractiveExample({ example, config }) {
  const [currentStep, setCurrentStep] = useState(0);
  const totalSteps = example.steps.length;

  const step = example.steps[currentStep];

  const nextStep = () => {
    if (currentStep < totalSteps - 1) {
      const newStep = currentStep + 1;
      setCurrentStep(newStep);
      // Track interactive example step
      trackInteractiveExampleStep(
        config.id,
        config.title,
        example.title,
        newStep + 1,
        totalSteps
      );
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="bg-white border-2 border-gray-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition sm:col-span-2">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-500 to-red-600 px-4 sm:px-5 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2 text-white">
          <span className="text-xl">{example.icon}</span>
          <span className="font-bold text-xs sm:text-sm uppercase tracking-wide">Real-world Example</span>
        </div>
        <span className="text-white text-sm font-semibold">Step {currentStep + 1}/{totalSteps}</span>
      </div>

      {/* Main Content Area */}
      <div className="p-4 sm:p-6">
        {/* Title */}
        <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">{example.title}</h3>

        {/* Two Column Layout */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* LEFT: Larger Card Stack */}
          <div className="relative" style={{ height: '520px' }}>
            {/* Stacked Cards */}
            {example.images.map((img, idx) => {
              const isActive = step.imageIndex === idx;
              const isPast = idx < step.imageIndex;
              const isFuture = idx > step.imageIndex;
              
              let transform = '';
              let zIndex = 0;
              let opacity = 1;
              
              if (isFuture) {
                const offset = (idx - step.imageIndex) * 20;
                transform = `translateX(${offset}px) scale(${1 - (idx - step.imageIndex) * 0.05})`;
                zIndex = totalSteps - idx;
                opacity = 0.6;
              } else if (isActive) {
                transform = 'translateX(0) scale(1)';
                zIndex = totalSteps;
                opacity = 1;
              } else if (isPast) {
                const offset = (step.imageIndex - idx) * -30;
                transform = `translateX(${offset}px) scale(${1 - (step.imageIndex - idx) * 0.05})`;
                zIndex = idx;
                opacity = 0.3;
              }
              
              return (
                <div
                  key={idx}
                  className="absolute inset-0 rounded-lg overflow-hidden shadow-lg bg-white transition-all duration-500 ease-out"
                  style={{ transform, zIndex, opacity }}
                >
                  <img src={img} alt={`Step ${idx + 1}`} className="w-full h-full object-contain" />
                  
                  {isActive && (
                    <>
                      {step.highlights?.map((highlight, hIdx) => (
                        <div
                          key={hIdx}
                          className="absolute border-3 border-red-500 rounded bg-red-500 bg-opacity-10 animate-pulse pointer-events-none"
                          style={{
                            top: highlight.top,
                            left: highlight.left,
                            width: highlight.width,
                            height: highlight.height,
                            boxShadow: '0 0 0 3px rgba(239, 68, 68, 0.3)',
                          }}
                        />
                      ))}

                      {step.arrows?.map((arrow, aIdx) => (
                        <div
                          key={aIdx}
                          className="absolute pointer-events-none hidden sm:block"
                          style={{
                            top: arrow.top,
                            left: arrow.left,
                            animation: 'bounce 1.5s ease-in-out infinite',
                          }}
                        >
                          <svg width="40" height="40" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <path
                              d="M50 10 L50 70 M50 70 L30 50 M50 70 L70 50"
                              stroke={arrow.color || "#ef4444"}
                              strokeWidth="9"
                              fill="none"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              style={{ filter: 'drop-shadow(0 2px 6px rgba(239, 68, 68, 0.5))' }}
                            />
                          </svg>
                        </div>
                      ))}

                      {step.labels?.map((label, lIdx) => (
                        <div
                          key={lIdx}
                          className="absolute bg-red-500 bg-opacity-95 text-white px-2.5 py-1.5 rounded-md text-xs font-bold shadow-lg pointer-events-none"
                          style={{
                            top: label.top,
                            left: label.left,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {label.text}
                        </div>
                      ))}
                    </>
                  )}
                </div>
              );
            })}
          </div>

          {/* RIGHT: Info Panel */}
          <div className="flex flex-col justify-between">
            {/* Step Description */}
            <div className="space-y-4">
              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg px-4 py-3">
                <p className="text-base text-blue-900 leading-relaxed font-medium">{step.text}</p>
              </div>

              {/* Key Insights - Use the empty space! */}
              <div className="bg-purple-50 border-2 border-purple-200 rounded-lg px-4 py-3">
                <h4 className="text-sm font-bold text-purple-900 mb-2 flex items-center gap-2">
                  <span>💡</span> What to Notice:
                </h4>
                <ul className="text-sm text-purple-800 space-y-1.5">
                  {currentStep === 0 && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Look for the "GET STARTED" button</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Notice the friendly, harmless appearance</span>
                      </li>
                    </>
                  )}
                  {currentStep === 1 && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Still looks innocent at this stage</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>The deception isn't obvious yet</span>
                      </li>
                    </>
                  )}
                  {currentStep === 2 && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Gray "MANAGE" button is easy to miss</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Blue "ACCEPT" button grabs your attention</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Deliberately designed to push you toward "Accept"</span>
                      </li>
                    </>
                  )}
                  {currentStep === 3 && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Accepting = one click, easy</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Rejecting = multiple steps, confusing</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>This imbalance is the obstruction pattern</span>
                      </li>
                    </>
                  )}
                  {currentStep === 4 && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Toggle wording: "Allowed" ON = ads allowed</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Must toggle LEFT to protect privacy</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-600">•</span>
                        <span>Confusing design makes users unsure</span>
                      </li>
                    </>
                  )}
                </ul>
              </div>

              {/* Progress Dots */}
              <div className="flex gap-2">
                {example.steps.map((_, idx) => (
                  <div
                    key={idx}
                    className={`h-2 rounded-full transition-all ${
                      idx === currentStep
                        ? 'bg-blue-500 w-8'
                        : idx < currentStep
                        ? 'bg-blue-300 w-2'
                        : 'bg-gray-300 w-2'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Controls */}
            <div className="flex justify-between items-center gap-3 mt-6">
              <button
                onClick={prevStep}
                disabled={currentStep === 0}
                className="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-200 transition flex items-center gap-2"
              >
                <ChevronLeft className="w-4 h-4" /> Previous
              </button>
              <button
                onClick={nextStep}
                disabled={currentStep === totalSteps - 1}
                className={`px-5 py-2.5 rounded-lg font-semibold text-sm transition flex items-center gap-2 ${
                  currentStep === totalSteps - 1
                    ? 'bg-green-500 text-white cursor-default'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                {currentStep === totalSteps - 1 ? (
                  <>Completed ✓</>
                ) : (
                  <>Next <ChevronRight className="w-4 h-4" /></>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LearningPhase({ phase, onNext, config, textSizeScale = { base: 'text-base', large: 'text-lg', xl: 'text-xl', '2xl': 'text-2xl', '3xl': 'text-3xl' } }) {
  return (
    <div className="flex flex-col gap-6">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-6 text-white">
        <p className="text-xl font-semibold leading-relaxed">{phase.summary}</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-5">
        {phase.keyPoints.map((point, i) => {
          // Check if this is an interactive example
          if (point.interactive) {
            return <InteractiveExample key={i} example={point.interactive} config={config} />;
          }
          
          // Regular card
          return (
            <div key={i} className="bg-white border-2 border-gray-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition">
              <div className="text-4xl mb-3">{point.icon}</div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{point.title}</h3>
              <p className="text-base text-gray-600 leading-relaxed whitespace-pre-line">{point.text}</p>
            </div>
          );
        })}
      </div>
      <div className="flex justify-end">
        <button onClick={onNext} className="btn-primary">
          Continue <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

function TestPhase({ phase, onComplete, textSizeScale = { base: 'text-base', large: 'text-lg', xl: 'text-xl' } }) {
  const [testCompleted, setTestCompleted] = useState(false);

  // Listen for completion message from iframe
  useEffect(() => {
    const handleMessage = (event) => {
      // Check if message is from test completion
      if (event.data.type === 'test-complete' && event.data.passed) {
        setTestCompleted(true);
        // Scroll to show the completion button
        setTimeout(() => {
          window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }, 300);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // If this is a simulation-based test
  if (phase.isSimulation) {
    return (
      <div className="flex flex-col gap-6">
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 text-amber-800 text-base font-medium">
          🎯 {phase.instruction}
        </div>
        <div className="w-full rounded-2xl overflow-hidden border-2 border-gray-200 shadow-lg" style={{ height: "680px" }}>
          <iframe
            src={phase.iframeSrc}
            className="w-full h-full"
            title="Test simulation"
          />
        </div>
        
        {/* Completion Button - Only shows after test is PASSED */}
        {testCompleted && (
          <div className="bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 border-4 border-green-400 rounded-2xl p-8 text-center shadow-2xl">
            <div className="text-6xl mb-4 animate-bounce">🎉</div>
            <h3 className="text-2xl sm:text-3xl font-black text-gray-900 mb-3">
              Excellent Work!
            </h3>
            <p className="text-base sm:text-lg text-gray-700 mb-6 max-w-xl mx-auto">
              You've successfully completed the test! You can now protect yourself from obstruction dark patterns. Ready to celebrate your achievement?
            </p>
            <button 
              onClick={onComplete}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-black text-lg sm:text-xl py-4 px-10 sm:px-12 rounded-xl transition shadow-lg hover:shadow-2xl hover:scale-105 transform inline-flex items-center gap-3"
            >
              <span className="text-2xl">🏆</span>
              <span>Complete Module & Celebrate!</span>
            </button>
            <p className="text-sm text-gray-600 mt-4">
              Click above to see your achievement certificate
            </p>
          </div>
        )}
      </div>
    );
  }

  // Otherwise, use question-based test
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const allAnswered = phase.questions.every(q => answers[q.id]);

  const score = useMemo(() => {
    if (!submitted) return 0;
    return phase.questions.filter(q => answers[q.id] === q.correct).length;
  }, [submitted]);

  const passed = score >= Math.ceil(phase.questions.length * 0.75);

  const handleRetry = () => { setAnswers({}); setSubmitted(false); };

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-6 py-8">
        <div className={`text-8xl ${passed ? "animate-bounce" : ""}`}>
          {passed ? "🎉" : "😅"}
        </div>
        <div className={`text-center rounded-2xl p-8 w-full max-w-md border-2 ${passed ? "bg-green-50 border-green-300" : "bg-orange-50 border-orange-300"}`}>
          <p className="text-4xl font-bold mb-2" style={{ color: passed ? "#16a34a" : "#ea580c" }}>
            {score} / {phase.questions.length}
          </p>
          <p className="text-xl font-semibold text-gray-800 mb-1">
            {passed ? "Well done! Module complete!" : "Almost there!"}
          </p>
          <p className="text-base text-gray-600">
            {passed ? "You've successfully completed this module." : "Review the learning section and try again."}
          </p>
        </div>
        <div className="w-full flex flex-col gap-4">
          {phase.questions.map((q, i) => {
            const isCorrect = answers[q.id] === q.correct;
            return (
              <div key={q.id} className={`rounded-xl p-4 border-2 ${isCorrect ? "border-green-300 bg-green-50" : "border-red-300 bg-red-50"}`}>
                <div className="flex items-start gap-2 mb-2">
                  {isCorrect ? <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" /> : <XCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />}
                  <p className="text-base font-semibold text-gray-900">{i + 1}. {q.question}</p>
                </div>
                {!isCorrect && (
                  <p className="text-sm text-gray-700 ml-7">
                    ✅ Correct: <span className="font-semibold">{q.options.find(o => o.id === q.correct)?.text}</span>
                  </p>
                )}
              </div>
            );
          })}
        </div>
        <div className="flex gap-4">
          {!passed && <button onClick={handleRetry} className="btn-secondary">Try Again</button>}
          {passed && (
            <button onClick={onComplete} className="btn-primary">
              Back to Home <Home className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 text-amber-800 text-base font-medium">
        📝 Answer all questions. You need 75% to pass.
      </div>
      {phase.questions.map((q, i) => (
        <div key={q.id} className="bg-white border-2 border-gray-200 rounded-2xl p-6 shadow-sm">
          <p className="text-lg font-bold text-gray-900 mb-5">{i + 1}. {q.question}</p>
          <div className="grid gap-3">
            {q.options.map(opt => {
              const isSelected = answers[q.id] === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => setAnswers(prev => ({ ...prev, [q.id]: opt.id }))}
                  className={`w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-all flex items-center gap-3
                    ${isSelected
                      ? "border-2 border-purple-500 bg-purple-50 text-purple-800"
                      : "border-2 border-gray-200 bg-gray-50 text-gray-700 hover:border-purple-300 hover:bg-purple-50"
                    }`}
                >
                  <span className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center
                    ${isSelected ? "border-purple-500 bg-purple-500" : "border-gray-400"}`}>
                    {isSelected && <span className="w-2 h-2 rounded-full bg-white" />}
                  </span>
                  {opt.text}
                </button>
              );
            })}
          </div>
        </div>
      ))}
      {allAnswered && (
        <div className="flex justify-end">
          <button onClick={() => setSubmitted(true)} className="btn-primary">
            Submit Answers <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}

// Congratulations/Completion Phase
function CongratulationsPhase({ config, onGoHome }) {
  return (
    <div className="flex flex-col items-center gap-8 py-12 px-4">
      {/* Celebration Animation */}
      <div className="text-9xl animate-bounce">
        🎉
      </div>

      {/* Congratulations Card */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-3xl p-8 sm:p-10 max-w-2xl w-full shadow-xl text-center">
        <h1 className="text-3xl sm:text-4xl font-black text-gray-900 mb-3">
          Congratulations! 🎊
        </h1>
        <p className="text-xl sm:text-2xl font-bold text-green-700 mb-4">
          You've Completed: {config.title}
        </p>
        <p className="text-base sm:text-lg text-gray-700 mb-6">
          You've successfully learned how to recognize and protect yourself from the <span className="font-bold text-green-800">{config.title}</span> dark pattern!
        </p>

        {/* Achievement Badge */}
        <div className="inline-block bg-white rounded-2xl px-6 py-4 shadow-md mb-8">
          <div className="flex items-center gap-3">
            <span className="text-4xl">✓</span>
            <div className="text-left">
              <p className="text-sm font-semibold text-gray-600">Module Completed</p>
              <p className="text-lg font-bold text-gray-900">{config.title}</p>
            </div>
          </div>
        </div>

        {/* What's Next */}
        <div className="bg-white rounded-xl p-5 mb-6 text-left">
          <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
            <span>🚀</span> What's Next?
          </h3>
          <ul className="space-y-2 text-sm sm:text-base text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold flex-shrink-0">✓</span>
              <span>Continue to the next module to learn about other dark patterns</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold flex-shrink-0">✓</span>
              <span>Share what you've learned with friends and family</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold flex-shrink-0">✓</span>
              <span>Stay vigilant when browsing online!</span>
            </li>
          </ul>
        </div>

        {/* Post-Survey Section */}
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-300 rounded-xl p-5 mb-6">
          <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
            <span>📋</span> Help Us Improve!
          </h3>
          <p className="text-sm text-gray-700 mb-4">
            Your feedback helps us make this learning experience better for everyone.
          </p>
          
          {/* POST-SURVEY LINK PLACEHOLDER */}
          <a
            href="https://forms.google.com/your-survey-link-here"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackSurveyClick(config.id, config.title)}
            className="inline-block w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition shadow-md hover:shadow-lg"
          >
            📝 Take Post-Module Survey
          </a>
          <p className="text-xs text-gray-500 mt-2">Takes about 2-3 minutes</p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
          <button
            onClick={onGoHome}
            className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold py-3 px-6 rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2"
          >
            <span>🏠</span> Back to Home
          </button>
          <button
            onClick={onGoHome}
            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2"
          >
            Next Module <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Confetti Effect (CSS) */}
      <style>{`
        @keyframes confetti-fall {
          0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

export default function Module() {
  const { id } = useParams();
  const navigate = useNavigate();
  const config = MODULE_CONFIGS[Number(id)];

  const [currentPhase, setCurrentPhase] = useState("experience");
  const [unlockedPhases, setUnlockedPhases] = useState(["experience"]);
  const [moduleCompleted, setModuleCompleted] = useState(false);

  // Load text size from cookies
  const [textSize, setTextSize] = useState(() => {
    const savedSize = Cookies.get('dptrek_textsize');
    return savedSize || "medium";
  });

  // Text size scaling (same as Home.jsx)
  const textSizeScale = useMemo(() => {
    const scales = {
      small: {
        base: 'text-sm',
        large: 'text-base',
        xl: 'text-lg',
        '2xl': 'text-xl',
        '3xl': 'text-2xl',
      },
      medium: {
        base: 'text-base',
        large: 'text-lg',
        xl: 'text-xl',
        '2xl': 'text-2xl',
        '3xl': 'text-3xl',
      },
      large: {
        base: 'text-lg',
        large: 'text-xl',
        xl: 'text-2xl',
        '2xl': 'text-3xl',
        '3xl': 'text-4xl',
      }
    };
    return scales[textSize] || scales.medium;
  }, [textSize]);

  // Save text size when it changes
  useEffect(() => {
    Cookies.set('dptrek_textsize', textSize, { expires: 365 });
  }, [textSize]);

  if (!config) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-700 mb-4">Module not found</p>
          <Link to="/" className="text-purple-600 font-semibold hover:underline">← Back to Home</Link>
        </div>
      </div>
    );
  }

  const currentIndex = PHASES.indexOf(currentPhase);

  // Track module start on mount
  useEffect(() => {
    trackModuleStart(config.id, config.title);
  }, [config.id, config.title]);

  const goToNextPhase = () => {
    const next = PHASES[currentIndex + 1];
    if (next) {
      // Track phase completion
      trackPhaseComplete(config.id, config.title, currentPhase);
      
      setUnlockedPhases(prev => prev.includes(next) ? prev : [...prev, next]);
      setCurrentPhase(next);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleComplete = () => {
    // Track module completion
    trackModuleComplete(config.id, config.title);
    
    setModuleCompleted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleGoHome = () => {
    navigate("/");
  };

  const phaseData = config.phases[currentPhase];

  // Show congratulations page if module completed
  if (moduleCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
        <div className="bg-white border-b-2 border-gray-200 shadow-sm sticky top-0 z-10">
          <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-center gap-2">
            <img 
              src="/DPTrek_logo.png" 
              alt="DP Trek" 
              className="h-10 w-auto"
            />
          </div>
        </div>
        <CongratulationsPhase config={config} onGoHome={handleGoHome} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b-2 border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2 text-gray-500 hover:text-purple-700 font-semibold transition flex-shrink-0">
            <ChevronLeft className="w-5 h-5" />
            <img 
              src="/DPTrek_logo.png" 
              alt="DP Trek" 
              className="h-10 w-auto"
            />
          </Link>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {PHASES.map((phase, i) => (
              <div key={phase} className="flex items-center gap-2 flex-shrink-0">
                <PhaseTab
                  phase={phase}
                  isActive={currentPhase === phase}
                  isUnlocked={unlockedPhases.includes(phase)}
                  onClick={setCurrentPhase}
                />
                {i < PHASES.length - 1 && (
                  <div className={`w-6 h-0.5 flex-shrink-0 ${unlockedPhases.includes(PHASES[i + 1]) ? "bg-purple-300" : "bg-gray-200"}`} />
                )}
              </div>
            ))}
          </div>
          
          {/* Text Size Controls */}
          <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
            <span className="text-xs font-semibold text-gray-500">Size:</span>
            <button
              onClick={() => setTextSize("small")}
              className={`w-8 h-8 rounded-lg text-sm font-bold transition ${
                textSize === "small" ? "bg-purple-600 text-white shadow-md" : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              A
            </button>
            <button
              onClick={() => setTextSize("medium")}
              className={`w-8 h-8 rounded-lg text-base font-bold transition ${
                textSize === "medium" ? "bg-purple-600 text-white shadow-md" : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              A
            </button>
            <button
              onClick={() => setTextSize("large")}
              className={`w-8 h-8 rounded-lg text-lg font-bold transition ${
                textSize === "large" ? "bg-purple-600 text-white shadow-md" : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              A
            </button>
          </div>
          
          <div className={`${textSizeScale.base} font-semibold text-gray-500 flex-shrink-0`}>
            {currentIndex + 1} / {PHASES.length}
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
        <div className="mb-8">
          <span className={`${textSizeScale.base} font-bold text-purple-600 uppercase tracking-widest`}>Module {config.id}</span>
          <h1 className={`${textSizeScale['3xl']} font-bold text-gray-900 mt-1`}>{config.title}</h1>
          <p className={`${textSizeScale.large} text-gray-500 mt-1`}>{config.subtitle}</p>
        </div>

        {currentPhase === "experience"  && <IframePhase    phase={phaseData} onNext={goToNextPhase} textSizeScale={textSizeScale} />}
        {currentPhase === "reflection"  && <ReflectionPhase phase={phaseData} onNext={goToNextPhase} textSizeScale={textSizeScale} />}
        {currentPhase === "learning"    && <LearningPhase  phase={phaseData} onNext={goToNextPhase} config={config} textSizeScale={textSizeScale} />}
        {currentPhase === "experiment"  && <IframePhase    phase={phaseData} onNext={goToNextPhase} textSizeScale={textSizeScale} />}
        {currentPhase === "test"        && <TestPhase      phase={phaseData} onComplete={handleComplete} textSizeScale={textSizeScale} />}
      </main>

      <style>{`
        .btn-primary {
          display: inline-flex; align-items: center; gap: 0.5rem;
          background: #7c3aed; color: white; font-weight: 700;
          font-size: 1rem; padding: 0.75rem 1.75rem;
          border-radius: 0.75rem; transition: background 0.2s; cursor: pointer;
        }
        .btn-primary:hover { background: #6d28d9; }
        .btn-secondary {
          display: inline-flex; align-items: center; gap: 0.5rem;
          background: #f3f4f6; color: #374151; font-weight: 700;
          font-size: 1rem; padding: 0.75rem 1.75rem;
          border-radius: 0.75rem; transition: background 0.2s; cursor: pointer;
        }
        .btn-secondary:hover { background: #e5e7eb; }
        
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
      `}</style>
    </div>
  );
}