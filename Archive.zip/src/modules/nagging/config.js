export const naggingConfig = {
  id: 2,
  title: "Nagging",
  
  phases: {
    experience: {
      type: "iframe",
      title: "Experience Nagging",
      subtitle: "See how websites repeatedly ask for permissions",
      instruction: "Browse this shopping website and notice what happens when you try to dismiss notifications.",
      iframeSrc: "/modules/nagging/experience.html",
      example: {
        title: "Understanding Notification Nagging",
        cards: [
          {
            image: "/nagging-example-1.png",
            title: "The First Request",
            description: "You're browsing a shopping website when suddenly a popup appears asking to send you notifications."
          },
          {
            image: "/nagging-example-2.png", 
            title: "The Persistence",
            description: "You click 'Not Now' but the popup appears again... and again... wearing you down until you give in."
          },
          {
            image: "/nagging-example-3.png",
            title: "The Consequence",
            description: "If you click 'Allow' just to make it stop, you'll be bombarded with promotional alerts and ads constantly."
          }
        ]
      }
    },

    reflection: {
      type: "questions",
      title: "Reflect on What You Saw",
      subtitle: "Think about your experience with nagging patterns",
      questions: [
        {
          id: "r1",
          type: "multiple-choice-text",
          question: "What observation do you have from the previous example?",
          options: [
            "I chose 'Not now', the website displays multiple prompts to register for the notification again and again.",
            "I choose 'Ok', the website displays multiple promotional notification at the same time.",
            "I didn't notice anything special.",
            "I didn't notice anything special."
          ],
          hasTextArea: true,
          textAreaPlaceholder: "Other, please specify below..."
        },
        {
          id: "r2",
          type: "scale",
          question: "Please choose the degree of your feeling:",
          scaleType: "1-5",
          labels: {
            min: "1 (Extremely)",
            max: "5 (Extremely)"
          },
          options: [
            { value: 1, label: "1" },
            { value: 2, label: "2" },
            { value: 3, label: "3" },
            { value: 4, label: "4" },
            { value: 5, label: "5" }
          ]
        },
        {
          id: "r3",
          type: "single-choice",
          question: "Have you encountered anything similar to the previous example in your daily life?",
          options: [
            "Always",
            "Often", 
            "Seldom",
            "Rarely",
            "Never"
          ],
          hasTextArea: true,
          textAreaPlaceholder: "If you have encountered before, please provide details below..."
        }
      ]
    },

    learning: {
      type: "content",
      title: "Understanding Nagging",
      subtitle: "Learn how this dark pattern works and why it's harmful",
      content: {
        definition: {
          term: "Nagging",
          explanation: "Nagging refers to a manipulative pattern that uses repeated requests or interruptions in an attempt to get you to do something that they can persistently interrupted by requests to do something that may not be in their best interest."
        },
        
        description: "When you're persistently interrupted, you're more likely to give in just to make it stop. For example, you're likely to eventually allow the website to send notifications just because they keep repeatedly asking you to and you're frustrated by the constant interruptions and just want to get on with what you were trying to do.",

        realWorldExamples: [
          {
            title: "Real-world example #1: Instagram",
            description: "In 2018, Instagram aggressively nagged users to turn on notifications, pestering this regularly over a period of months. Users were not able to say NO - the only option to make the nagging stop was to turn on notifications.",
            image: "/nagging-instagram-example.png"
          },
          {
            title: "Real-world example #2: Google Location",
            description: "Google repeatedly asks for permission to use location data, only allowing 'Not now' to be selected - pestering the user until they give permission.",
            image: "/nagging-google-example.png"
          }
        ],

        howToProtect: [
          "Look for ways to 'Leave or Report' the website if the nagging becomes too persistent",
          "You can consider leaving the website or reporting it if you don't want the notifications but the website doesn't stop bothering you",
          "Remember: websites that respect users will accept 'No' the first time"
        ]
      }
    },

    experiment: {
      type: "iframe",
      title: "Now You Try It",
      subtitle: "Apply what you've learned",
      instruction: "You're shopping for a backpack. The website asks you to subscribe. What will you do?",
      iframeSrc: "/modules/nagging/experiment.html"
    },

    test: {
      type: "iframe", 
      title: "Test Your Knowledge",
      subtitle: "Can you spot and avoid nagging?",
      instruction: "Complete these scenarios to test what you've learned about nagging patterns.",
      iframeSrc: "/modules/nagging/test.html"
    }
  }
};

export default naggingConfig;